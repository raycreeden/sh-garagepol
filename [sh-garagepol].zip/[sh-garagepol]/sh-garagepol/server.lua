local QBCore = exports['qb-core']:GetCoreObject()

RegisterNetEvent("sh-garagepol:registrarVehiculoServer", function(plate, model)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return end

    -- 🔒 Verificamos que sea policía
    if Player.PlayerData.job.name ~= "police" or Player.PlayerData.job.type ~= "leo" then
        print(('[sh-garagepol] %s intentó registrar vehículo pero no es policía leo'):format(Player.PlayerData.name))
        return
    end

    -- 🧠 Si querés desactivar el registro, simplemente salimos acá
    return -- ❌ Esto evita que se registre el vehículo

    -- ⬇ Si alguna vez querés activarlo de nuevo, descomentá desde acá
    -- local license = Player.PlayerData.license
    -- local citizenid = Player.PlayerData.citizenid
    -- local hash = GetHashKey(model)
    -- local mods = '{}'
    -- local garageName = 'police'
    -- local state = 1
    -- local fuel = 100
    -- local engine = 1000
    -- local body = 1000
    -- local depotprice = 0
    -- local balance = 0

    -- MySQL.insert('INSERT INTO player_vehicles (license, citizenid, vehicle, hash, mods, plate, garage, state, fuel, engine, body, depotprice, balance) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)', {
    --     license, citizenid, model, hash, mods, plate, garageName, state, fuel, engine, body, depotprice, balance
    -- }, function(affectedRows)
    --     if affectedRows and affectedRows > 0 then
    --         print(('[sh-garagepol] %s (%s) registró vehículo: %s [%s]'):format(Player.PlayerData.name, citizenid, model, plate))
    --         TriggerClientEvent('qb-garages:client:RefreshGarage', src)
    --         TriggerClientEvent('QBCore:Notify', src, 'Vehículo registrado a tu nombre correctamente.', 'success', 4000)
    --     else
    --         print('[sh-garagepol] ERROR al insertar vehículo en DB')
    --         TriggerClientEvent('QBCore:Notify', src, 'Error al registrar vehículo.', 'error', 4000)
    --     end
    -- end)
end)
