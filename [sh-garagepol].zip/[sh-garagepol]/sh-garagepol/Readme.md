# Qb-core 
# Sitema  Super Personalizado de Spawn y Despawn de vehiculos policiales. 
# Poner en la carpeta Resources  darle ensure a "sh-garagepol" y a correr 
- Spawner mediante interface, seccionado por " Divisiones "  de la fuerza policial de el server que uses, ya que son modificables desde config,  vehiculos con rangos para ser vistos, es decir depende del rango verán distintos coches a elegir, modificable desde el config, puedes agregar los vehiculos que quieran desde el config. y  luego el apartado de spawn, de todos los coches que pongan en cada seccion de division deben crear el apartado que hace que salga con sus extrar  y liveries de los vehiculos que quieran ya sean los vanilla del juego y los que le puse yo o los que tengan comprados o hayan armado ustedes, eso da igual solo deben meter al config lo que quieran poner . 
 El turbo funciona bastante intuitivo, desde el config, le dan a eneable true o false y lo mismo para que al spawnear el coche ya salga on el turbo o pueden poner para que deba aplicarse el /turbo o no .  cada coche usa su propio valor de  el coheficiente que modifican. 

  # GitHub - https://github.com/raycreeden/sh-garagepol