Config = {}

Config.GarageLocation = vector4(441.59, -974.81, 25.7, 172.32)
Config.SpawnLocation = vector4(458.39, -992.54, 25.18, 3.65)

-- Turbo global / zona (si quieres exigir estar en banco/puesto para activar)
Config.Turbo = {
    requireZone = true,
    coords = vector3(436.31, -976.18, 25.7), -- por defecto el que usabas
    maxDistance = 3.0
}

-- 🔹 Definición de divisiones con colores y vehículos
Config.Divisions = {
    LSPD = {
        label = "LSPD",
        vehicles = {
            { model = 'pbus',            name = 'Police Prison Bus',           brand = 'Vapid',    rank = 2 },
            { model = 'police5',         name = 'Cruiser Mod',                 brand = 'Vapid',    rank = 2 },
            { model = 'police3',         name = 'Police Torrence',             brand = 'Vapid',    rank = 2 },
            { model = 'police2',         name = 'Buffalo Basico',              brand = 'Bravado',  rank = 2 },
            { model = 'polgauntlet',     name = 'Police Gauntlet Interceptor', brand = 'Bravado',  rank = 2 },
            { model = 'policet',         name = 'Police Transporter',          brand = 'Vapid',    rank = 1 },
            { model = 'policeb',         name = 'Police Bike',                 brand = 'Vapid',    rank = 0 },
            { model = 'policeb2',        name = 'Police Bike2',                brand = 'Vapid',    rank = 0 },
            { model = 'poldorado',       name = 'Dorado Cruiser',              brand = 'Bravado',  rank = 0 },
            { model = 'polbuffalo4',     name = 'Buffalo STX',                 brand = 'Bravado',  rank = 0 },
            { model = 'polcoquette4',    name = 'Coquette D10 Pursuit',        brand = 'Invetero', rank = 0 },
            { model = 'polterminus',     name = 'Terminus Patrol',             brand = 'Canis',    rank = 0 },
            { model = 'poldominator10',  name = 'Dominator FX Interceptor',    brand = 'Vapid',    rank = 0 },
            { model = 'polgreenwood',    name = 'Greenwood Cruiser',           brand = 'Bravado',  rank = 0 },
            { model = 'polimpaler6',     name = 'Impaler LX Cruiser',          brand = 'Declasse', rank = 0 },
            { model = 'nkstanier',       name = 'Stanier Pol',                 brand = 'Vapid',    rank = 2 },
            { model = 'polcaracara',     name = 'Caracara Pol',                brand = 'Vapid',    rank = 2 },     
            { model = 'nkbuffalos',      name = 'BuffaloS Pol',                brand = 'Bravado',  rank = 2 }, 
            { model = 'nkscout',         name = 'Scout Pol',                   brand = 'Vapid',    rank = 2 },
            { model = 'pd_chavosv6',     name = 'Police Chavos V6',            brand = 'Dinka',    rank = 2 },
            { model = 'polbuffev',       name = 'BuffaloEv Pol',               brand = 'Bravado',  rank = 2 },   
            { model = 'polweevil',       name = 'Escarabajo Pol',              brand = 'BF',       rank = 2 },      
            { model = 'polbuffwb',       name = 'Buffalo Wide Pol',            brand = 'Bravado',  rank = 2 },  
        }
    },
    METRO = {
        label = "METRO",
        vehicles = {
            { model = 'riot',  name = 'Police Riot',       brand = 'Brute',   rank = 4 },
            { model = 'riot2', name = 'RCV',               brand = 'Unknown', rank = 3 },
            { model = 'pbus',  name = 'Police Prison Bus', brand = 'Vapid',   rank = 2 },
        }
    },
    DB = {
        label = "DB",
        vehicles = {
            { model = 'riot',         name = 'DB Riot',              brand = 'Brute',   rank = 4 },
            { model = 'riot2',        name = 'DB RCV',               brand = 'Unknown', rank = 3 },
            { model = 'pbus',         name = 'DB Prison Bus',        brand = 'Vapid',   rank = 2 },
            { model = 'police2',      name = 'DB Buffalo',           brand = 'Vapid',   rank = 0 },
            { model = 'police3',      name = 'DB Interceptor',       brand = 'Vapid',   rank = 1 },
        }
    },
    RTD = {
        label = "RTD",
        vehicles = {
            { model = 'police2',      name = 'RTD Buffalo',          brand = 'Vapid',   rank = 0 },
            { model = 'police3',      name = 'RTD Interceptor',      brand = 'Vapid',   rank = 1 },
            { model = 'policeb',      name = 'RTD Bike',             brand = 'Vapid',   rank = 0 },
        }
    }
}

-- Configs específicas de vehículos (aquí defines mods, extras, ruedas, color y turbo por coche)
Config.VehicleMods = {
    ["poldominator10"] = {
        color = {14, 14},
        livery = 7,
        wheels = { type = 10, index = 10 },
        mods = {
            [0] = 7, [1] = 0, [2] = 0, [3] = 4, [4] = 1, [5] = -1, [7] = 6, [8] = 1, [9] = 1,
            [42] = 0, [48] = 7,
        },
        extras = {
            [1]=false,[2]=false,[3]=false,[4]=true,[5]=false,[6]=false,[7]=false,[8]=false,[9]=false,[10]=false,[11]=false,[12]=false,[13]=false
        },
        turbo = { enabled = true, multiplier = 1.51, applyOnSpawn = true, manual = false }
    },

    ["polgauntlet"] = {
        color = {14, 14},
        livery = 7,
        wheels = { type = 10, index = 10 },
        mods = {
            [0]=7,[1]=1,[2]=2,[3]=2,[4]=1,[5]=-1,[7]=9,[8]=0,[9]=-1,[10]=-1,[42]=6,[43]=6,[48]=18
        },
        extras = {
            [1]=false,[2]=false,[3]=true,[4]=false,[5]=true,[6]=false,[7]=false,[8]=false,[9]=false,[10]=false,[11]=false,[12]=false,[13]=false
        },
        turbo = { enabled = true, multiplier = 1.53, applyOnSpawn = true, manual = false }
    },

    ["polcoquette4"] = {
        color = {14, 14},
        livery = 7,
        wheels = { type = 10, index = 10 },
        mods = {
            [0]=7,[1]=0,[2]=-1,[3]=0,[4]=1,[5]=-1,[7]=9,[8]=0,[9]=-1,[10]=-1,[42]=6,[43]=3,[48]=18
        },
        extras = {
            [1]=false,[2]=false,[3]=true,[4]=false,[5]=true,[6]=false,[7]=false,[8]=false,[9]=false,[10]=false,[11]=true,[12]=false,[13]=false
        },
        turbo = { enabled = false, multiplier = 1.95, applyOnSpawn = true, manual = false }
    },

    ["police5"] = {
        color = {12, 131},
        livery = 7,
        wheels = { type = 10, index = 10 },
        mods = {
            [0]=7,[1]=1,[2]=2,[3]=2,[4]=1,[5]=-1,[7]=5,[8]=0,[9]=-1,[10]=-1,[42]=6,[43]=6,[48]=0
        },
        extras = {
            [1]=false,[2]=false,[3]=true,[4]=false,[5]=false,[6]=false,[7]=false,[8]=false,[9]=false,[10]=false,[11]=false,[12]=false,[13]=false
        },
        turbo = { enabled = false, multiplier = 1.90, applyOnSpawn = true, manual = false }
    },

    ["polterminus"] = {
        color = {12, 131},
        livery = 7,
        wheels = { type = 10, index = 10 },
        mods = {
            [0]=2,[1]=0,[2]=3,[3]=5,[4]=3,[5]=-1,[6]=5,[7]=9,[8]=-1,[9]=3,[10]=2,[42]=4,[43]=6,[46]=-1,[48]=0
        },
        extras = {
            [1]=false,[2]=false,[3]=true,[4]=false,[5]=false,[6]=false,[7]=false,[8]=false,[9]=false,[10]=false,[11]=false,[12]=false,[13]=false
        },
        turbo = { enabled = false, multiplier = 1.95, applyOnSpawn = false, manual = false }
    },

    ["poldorado"] = {
        color = {12, 131},
        livery = 7,
        wheels = { type = 10, index = 10 },
        mods = {
            [0]=12,[1]=7,[2]=4,[3]=14,[4]=2,[5]=7,[6]=0,[7]=14,[8]=-1,[9]=3,[10]=2,[42]=4,[43]=6,[46]=-1,[48]=0
        },
        extras = {
            [1]=false,[2]=false,[3]=true,[4]=false,[5]=false,[6]=false,[7]=false,[8]=false,[9]=false,[10]=false,[11]=false,[12]=false,[13]=false
        },
        turbo = { enabled = false, multiplier = 1.80, applyOnSpawn = false, manual = false }
    },

    ["polgreenwood"] = {
        color = {12, 131},
        livery = 7,
        wheels = { type = 10, index = 10 },
        mods = {
            [0]=12,[1]=7,[2]=4,[3]=14,[4]=2,[5]=0,[6]=0,[7]=1,[8]=-1,[9]=3,[10]=2,[42]=7,[43]=6,[46]=-1,[48]=1
        },
        extras = {
            [1]=true,[2]=false,[3]=false,[4]=false,[5]=false,[6]=false,[7]=false,[8]=true,[9]=false,[10]=false,[11]=false,[12]=false,[13]=false
        },
        turbo = { enabled = false, multiplier = 1.95, applyOnSpawn = true, manual = false }
    },

    ["polimpaler6"] = {
        color = {12, 131},
        livery = 7,
        wheels = { type = 10, index = 10 },
        mods = {
            [0]=0,[1]=8,[2]=5,[3]=1,[4]=-1,[5]=0,[6]=4,[7]=7,[8]=0,[9]=-1,[10]=2,[42]=7,[43]=6,[46]=-1,[48]=0
        },
        extras = {
            [1]=true,[2]=false,[3]=false,[4]=false,[5]=false,[6]=false,[7]=false,[8]=true,[9]=false,[10]=false,[11]=false,[12]=false,[13]=false
        },
        turbo = { enabled = false, multiplier = 1.95, applyOnSpawn = true, manual = false }
    },

    ["polcaracara"] = {
        color = {12, 131},
        livery = 7,
        wheels = { type = 10, index = 10 },
        mods = {
            [0]=0,[1]=6,[2]=4,[3]=1,[4]=1,[5]=0,[6]=-1,[7]=4,[8]=-1,[9]=-1,[10]=-1,[42]=4,[43]=6,[46]=-1,[48]=0
        },
        extras = {
            [1]=false,[2]=false,[3]=true,[4]=false,[5]=false,[6]=false,[7]=false,[8]=false,[9]=false,[10]=false,[11]=false,[12]=false,[13]=false
        },
        turbo = { enabled = false, multiplier = 1.95, applyOnSpawn = true, manual = false }
    },

    ["police2"] = {
        color = {131, 12},
        livery = 7,
        wheels = { type = 10, index = 10 },
        mods = {
            [0]=0,[1]=6,[2]=4,[3]=1,[4]=1,[5]=0,[6]=-1,[7]=4,[8]=-1,[9]=-1,[10]=-1,[42]=4,[43]=6,[46]=-1,[48]=0
        },
        extras = {
            [1]=true,[2]=false,[3]=false,[4]=false,[5]=false,[6]=false,[7]=false,[8]=false,[9]=false,[10]=false,[11]=false,[12]=false,[13]=false
        },
        turbo = { enabled = false, multiplier = 1.95, applyOnSpawn = true, manual = false }
    },

    ["nkscout"] = {
        color = {12, 131},
        livery = 7,
        wheels = { type = 10, index = 10 },
        mods = {
            [0]=6,[1]=1,[2]=4,[3]=3,[4]=4,[5]=0,[6]=4,[7]=4,[8]=-1,[9]=-1,[10]=-1,[27]=2,[42]=0,[43]=0,[44]=1,[45]=3,[46]=-1,[48]=0
        },
        extras = {
            [1]=true,[2]=true,[3]=true,[4]=true,[5]=true,[6]=true,[7]=false,[8]=false,[9]=false,[10]=false,[11]=false,[12]=false,[13]=false
        },
        turbo = { enabled = false, multiplier = 1.95, applyOnSpawn = true, manual = false }
    },

    ["polbuffalo4"] = {
        color = {12, 131},
        livery = 7,
        wheels = { type = 10, index = 10 },
        mods = {
            [0]=6,[1]=1,[2]=4,[3]=3,[4]=4,[5]=1,[6]=4,[7]=2,[8]=-1,[9]=-1,[10]=-1,[27]=2,[42]=0,[43]=0,[44]=1,[45]=3,[46]=-1,[48]=0
        },
        extras = {
            [1]=true,[2]=true,[3]=false,[4]=false,[5]=false,[6]=false,[7]=false,[8]=false,[9]=false,[10]=true,[11]=true,[12]=true,[13]=false
        },
        turbo = { enabled = false, multiplier = 1.95, applyOnSpawn = true, manual = false }
    },

    ["pd_chavosv6"] = {
        color = {12, 131},
        livery = 0,
        wheels = { type = 10, index = 10 },
        mods = {
            [0]=14,[1]=1,[2]=4,[3]=7,[4]=4,[5]=0,[6]=-1,[7]=8,[8]=-1,[9]=3,[10]=0,[27]=2,[42]=-1,[43]=-1,[44]=1,[45]=23,[46]=-1,[48]=0
        },
        extras = {
            [1]=true,[2]=true,[3]=true,[4]=true,[5]=true,[6]=true,[7]=true,[8]=true,[9]=true,[10]=false,[11]=true,[12]=true,[13]=true
        },
        turbo = { enabled = true, multiplier = 1.29, applyOnSpawn = true, manual = false }
    },

    ["nkstanier"] = {
        color = {12, 131},
        livery = 0,
        wheels = { type = 10, index = 10 },
        mods = {
            [0]=0,[1]=1,[2]=4,[3]=7,[4]=4,[5]=0,[6]=4,[7]=8,[8]=-1,[9]=-1,[10]=-1,[27]=2,[42]=-1,[43]=6,[44]=2,[45]=23,[46]=-1,[48]=0,[30]=0
        },
        extras = {
            [1]=true,[2]=true,[3]=true,[4]=true,[5]=false,[6]=false,[7]=false,[8]=false,[9]=true,[10]=true,[11]=true,[12]=true,[13]=true
        },
        turbo = { enabled = false, multiplier = 1.29, applyOnSpawn = true, manual = false }
    },
    
    ["police3"] = {
        color = {131, 12},
        livery = 0,
        wheels = { type = 10, index = 10 },
        mods = {
            [0]=1,[1]=1,[2]=1,[3]=1,[4]=4,[5]=1,[6]=4,[7]=1,[8]=-1,[9]=-1,[10]=-1,[27]=2,[42]=-1,[43]=6,[44]=2,[45]=23,[46]=-1,[48]=0,[30]=0
        },
        extras = {
            [1]=false,[2]=true,[3]=true,[4]=true,[5]=false,[6]=false,[7]=false,[8]=false,[9]=true,[10]=true,[11]=true,[12]=false,[13]=true
        },
        turbo = { enabled = false, multiplier = 1.29, applyOnSpawn = true, manual = false }
    },

    ["polmav"] = {
    color = {0, 0}, -- negro mate, puedes cambiar
    livery = 0,     -- skin policial aérea
    wheels = nil,   -- no aplica en helicópteros
    mods = { 
        [48] = 0, -- elegir livery policial
        [23] = -1,
        [21] = -1
    },
    extras = {
        [1] = true,  -- spotlight activado
        [2] = true, -- sin flotadores
        [7] = true,
        [10] = true,
        [11] = true
    },
    turbo = { enabled = false, multiplier = 1.0, applyOnSpawn = false, manual = false }
}

    -- si quieres puedes añadir más coches aquí siguiendo el patrón:
    -- ["modelo"] = { color = {primary,secondary}, livery = X, wheels = {...}, mods = {...}, extras = {...}, turbo = { enabled = true, multiplier = 1.95, applyOnSpawn = true, manual = true } }
}
